export const AuthModelApi = {

    api:{
        login:"/auth/login",
        signup:"/auth/signup",
        verifyOtp:"/auth/verify-otp",
        logout:"/auth/logout",
         googleLogin: "/api/auth/google-login",
    }

  };