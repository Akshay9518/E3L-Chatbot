export const SettingsApiRoutes ={
    api:{
      update_profile:"/auth/update-name", 
    }
}