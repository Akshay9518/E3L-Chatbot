export const SettingsUiRoutes ={
    url:{
      setting:"/settings", 
    }
}