 export const ROLE_API_URLS = {
    friend: '/api/chroma/friend/chat',
    mentor: '/api/chroma/mentor/chat',
    collegebuddy: '/api/chroma/collegebuddy/chat',
  };