export const HomePageUiRoutes ={
    url:{
      home:"/", 
      chat:"/chat/:randomString"
    }
}