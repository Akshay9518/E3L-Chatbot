export const DashboardApiRoutes = {
  api: {
    dashboard: "/api/dashboards",
  }
}