export const DashboardUiRoutes ={
    url:{
      dash:"/dashboard", 
    }
}