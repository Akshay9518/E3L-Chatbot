export const FRONTEND_PORT = 5173;
export const BACKEND_PORT = 5001; // Replace with your actual backend port
// export const BACKEND_HOST = 'beta.test.oneclarity.ai'; // Replace with your actual backend host or IP address
 export const BACKEND_HOST = '192.168.1.7'; // Replace with your actual backend host or IP address
export const API_URL = `http://${BACKEND_HOST}:${BACKEND_PORT}`;
export const GOOGLE_CLIENT_ID = '519379462163-a4in8tsl42f1a8atjaslho4j13vp5nsi.apps.googleusercontent.com'
